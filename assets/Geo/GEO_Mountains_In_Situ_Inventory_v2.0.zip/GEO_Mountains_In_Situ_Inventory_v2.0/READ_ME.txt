This inventory seeks to capture fundamental information which can be used to i) characterise existing in situ monitoring and data collection efforts spanning multiple disciplines, ii) find, access, and use the corresponding observations (often time-series), and iii) potentially identify existing gaps in data coverage (spatially, by elevation, by variable / theme, by time period, or some combination of the above), and by extensions provide recommendations for future infrastructure development. More generally, the inventory hopes to enhance monitoring collaboration and data exchange between institutions and disciplinary communities, while avoiding unnecessary redundancy (e.g. different groups share common instrumentation at a given site, instrumentation corresponding to different disciplines is co-located at a given site to enable co-benefit / cross-referencing, etc.).

In developing v1 (released July 2021) and v2 (released October 2022) of the inventory, the primary objective was to ensure that the maximum possible number of monitoring sites were represented (i.e., “put on the map”). The corresponding metadata (i.e., information characterising each site) was completed to the greatest extent possible based on information that was freely available online, complemented in some cases by information submitted directly to GEO Mountains by members of the network responsible for, or with knowledge of, mountain monitoring infrastructure in their regions. In v1, emphasis was mostly placed on collating information of monitoring sites operated by the research community (e.g., university groups), as opposed to operational agencies such as national hydrometeorological agencies. Such research-oriented stations / networks are generally not included in any other overarching database or inventory (to our best knowledge). Then, in v2, the scope was expanded to also include as many operational stations as possible, with station type (research-oriented or operational) indicated wherever possible.

GEO Mountains provides an online form  which can be used to submit information on in situ monitoring sites for consideration for inclusion in subsequent releases of the inventory. On the inventory webpage, we also provide some general guidance on the inventory’s scope and criteria for individual stations or networks to be included. In summary, sites must be in situ, fall within one or more of the global mountain delineations or else be considered mountains by the site manager / users, and – in accordance with the remit of GEO Mountains – be established relatively in the relatively long-term, ideally several years or decades. This means that sites which are just installed for a few months / a summer field season should generally not be included. Sites with long-term historical records, but which are no longer currently in operation, can also be included. 

The fields currently available (v2) are as follows: 

Field name:                                                                         |Type:                      |Example:
GEO Mountains ID                                                                    |Integer                    |1
Name                                                                                |Text                       |Sonnblick Integrated Site
Category                                                                            |Text                       |Network or Group of Sites/Stations
Latitude                                                                            |Float (decimal degrees)    |47.053
Longitude                                                                           |Float (decimal degrees)    |12.958
Elevation and/or range (m a.s.l)                                                    |Integer (or integer range) |1500–3600
Country                                                                             |Text                       |Austria
Purpose                                                                             |Text                       |Research
Operating Organization(s)                                                           |Text                       |ZAMG (Central Institute for Meteorology and Geodynamics, Austria)
URL(s) of site/station webpage                                                      |Text (URL)                 |https://www.sonnblick.net/en/
Email address or other contact                                                      |Text (Email address)       |https://www.sonnblick.net/en/contact/
Parameters measured                                                                 |Text (; seperated)         |Air temperature; wind speed; snow depth; glacier mass balance
Temporal coverage                                                                   |Integer range              |1986–Present
Temporal Frequency                                                                  |Text                       |Hourly
Measurement method(s) / protocol(s) followed                                        |Text                       |WGMS (for glacier mass balance)
Instrumentation Deployed                                                            |Text                       |Cambell MetPRO station
Data freely available for download (including via fast online inscription process)? |Text                       |Yes
URL(s) to data repository and download (if applicable)                              |Text (URL)                 |https://www.sonnblick.net/en/data/download-portal/sbo-data-portal/
DOI(s) of associated publication(s)                                                 |DOI string                 |10.1007/s00704-012-0689-8
Parent network and / or other comment(s)                                            |Text (; seperated)         |CryoNet Cluster site; VAO site; LTER site (https://deims.org/b2015216-ac0a-433f-8044-8ba8c46cc6c9);     																										          Only scientific and non-commercial use permitted

It is important to note that compared with most other existing inventories, which collate data on only one component of the Earth system (e.g. climate, cryosphere, hydrosphere, etc.), our inventory aimed to be flexible enough to collate monitoring site information corresponding to multiple disciplines, which often employ different monitoring and data collection strategies or methods. For example, long-term glacier and vegetation monitoring is often done via repeated surveys, as opposed to the continuous operation of fixed measurement and data logging infrastructure). 

To facilitate long-term discoverability and unique citation, a DOI was generated for each release of the inventory by creating a metadata entry on figshare (10.6084/m9.figshare.14899845.v2). 

If you use the inventory, please acknowledge using the following suggested citation: GEO Mountains (2022). Inventory of in situ mountain observational infrastructure, v2.0. DOI: 10.6084/m9.figshare.14899845.v2

